import SwiftUI
import UIKit
import WidgetKit
import PhotosUI

struct ContentView: View {
    @State private var config: RingConfig = ConfigStore.load()
    @State private var spinning = true
    @State private var spinAngle: Double = 0
    @State private var savedTip = false
    @State private var photoItem: PhotosPickerItem?
    @State private var wallpaperSource: UIImage?
    @State private var wallpaperPreview: UIImage?

    private var resolved: (center: LauncherApp, ring: [LauncherApp]) {
        ConfigStore.resolve(config)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    preview
                        .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
                        .listRowBackground(Color.clear)
                }

                Section("中心图标") {
                    Picker("中心 App", selection: $config.centerId) {
                        ForEach(Catalog.all) { app in
                            Text(app.name).tag(app.id)
                        }
                    }
                }

                Section("圆环图标（点右侧按钮换，长按拖动排序）") {
                    ForEach(config.ringIds, id: \.self) { id in
                        HStack(spacing: 12) {
                            if let app = Catalog.find(id) {
                                IconView(app: app, size: 30)
                            }
                            Text(Catalog.find(id)?.name ?? id)
                            Spacer()
                            Menu {
                                ForEach(Catalog.all) { candidate in
                                    Button(candidate.name) { replace(id, with: candidate.id) }
                                }
                            } label: {
                                Image(systemName: "arrow.left.arrow.right.circle")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .onMove { config.ringIds.move(fromOffsets: $0, toOffset: $1) }
                    .onDelete { config.ringIds.remove(atOffsets: $0) }

                    if config.ringIds.count < 14 {
                        Button("添加一个图标") { addNext() }
                    }
                }

                Section {
                    Picker("背景", selection: $config.background) {
                        Text("深色").tag("dark")
                        Text("浅色").tag("light")
                        Text("壁纸（透明效果）").tag("wallpaper")
                    }
                    if config.background == "wallpaper" {
                        PhotosPicker(selection: $photoItem, matching: .images) {
                            Label(wallpaperSource == nil && wallpaperPreview == nil
                                  ? "选一张空白桌面截图"
                                  : "重新选桌面截图",
                                  systemImage: "photo.on.rectangle")
                        }
                        Picker("组件摆的位置", selection: $config.wallpaperPosition) {
                            Text("上方").tag("top")
                            Text("中间").tag("middle")
                            Text("下方").tag("bottom")
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: config.wallpaperPosition) { _, _ in recropWallpaper() }
                    }
                    Toggle("预览旋转动画（仅 App 内）", isOn: $spinning)
                } header: {
                    Text("外观")
                } footer: {
                    if config.background == "wallpaper" {
                        Text("iOS 不允许小组件真透明，所以用这个办法：先把桌面图标挪开截一张空白壁纸图，在这里选它、再选组件摆的位置，组件会拿那块壁纸当背景，看起来就是透明的。位置对不准时换个位置档位再保存。")
                    }
                }

                Section {
                    Button {
                        ConfigStore.save(config)
                        WidgetCenter.shared.reloadAllTimelines()
                        savedTip = true
                    } label: {
                        Text("保存并刷新小组件")
                            .frame(maxWidth: .infinity)
                    }
                } footer: {
                    Text("保存后，回桌面长按空白处 → 点左上角 + → 搜索 Orbit Widgets → 选大号添加。免费签名可能拦住 App 与小组件之间的数据同步，拦住时小组件会先用默认布局（就是图片那套）。")
                }
            }
            .navigationTitle("Orbit Widgets")
            .toolbar { EditButton() }
            .alert("已保存", isPresented: $savedTip) {
                Button("好", role: .cancel) {}
            }
            .onOpenURL(perform: handleLaunch)
            .onChange(of: photoItem) { _, newItem in
                Task { await loadWallpaper(from: newItem) }
            }
            .onAppear {
                if wallpaperPreview == nil,
                   let data = ConfigStore.loadWallpaperData(),
                   let img = UIImage(data: data) {
                    wallpaperPreview = img
                }
            }
        }
    }

    @ViewBuilder
    private var previewBackground: some View {
        switch config.background {
        case "light":
            LinearGradient(colors: [Color.white, Color(hex: "#E9E9EF")], startPoint: .top, endPoint: .bottom)
        case "wallpaper":
            if let img = wallpaperPreview {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")], startPoint: .top, endPoint: .bottom)
            }
        default:
            LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")], startPoint: .top, endPoint: .bottom)
        }
    }

    private var preview: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(Color.clear)
                .background { previewBackground }
                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            RingCanvas(center: resolved.center, ring: resolved.ring, spin: spinning ? spinAngle : 0) { app, size in
                Button { open(app) } label: { IconView(app: app, size: size) }
                    .buttonStyle(.plain)
            }
            .padding(10)
        }
        .aspectRatio(1, contentMode: .fit)
        .onAppear {
            withAnimation(.linear(duration: 30).repeatForever(autoreverses: false)) {
                spinAngle = 360
            }
        }
    }

    // MARK: - Wallpaper

    private func loadWallpaper(from item: PhotosPickerItem?) async {
        guard let item,
              let data = try? await item.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else { return }
        await MainActor.run {
            wallpaperSource = image
            recropWallpaper()
        }
    }

    /// Crop the region the large widget will cover out of a full
    /// home-screen screenshot, and store it in the App Group container.
    private func recropWallpaper() {
        guard let source = wallpaperSource,
              let cg = source.cgImage else { return }
        let W = CGFloat(cg.width)
        let H = CGFloat(cg.height)
        let cropW = W * 0.92
        let cropH = min(cropW * (361.0 / 379.0), H)
        let x = (W - cropW) / 2
        let topFrac: CGFloat
        switch config.wallpaperPosition {
        case "top": topFrac = 0.10
        case "bottom": topFrac = 0.50
        default: topFrac = 0.30
        }
        let y = min(max(H * topFrac, 0), H - cropH)
        let rect = CGRect(x: x, y: y, width: cropW, height: cropH)
        guard let cropped = cg.cropping(to: rect) else { return }
        let image = UIImage(cgImage: cropped)
        wallpaperPreview = image
        if let jpeg = image.jpegData(compressionQuality: 0.9) {
            ConfigStore.saveWallpaper(jpeg)
        }
    }

    // MARK: - Actions

    private func replace(_ oldId: String, with newId: String) {
        guard let idx = config.ringIds.firstIndex(of: oldId) else { return }
        if newId == config.centerId { return }
        if let existing = config.ringIds.firstIndex(of: newId) {
            config.ringIds.swapAt(idx, existing)   // swap instead of duplicating
        } else {
            config.ringIds[idx] = newId
        }
    }

    private func addNext() {
        let used = Set(config.ringIds + [config.centerId])
        if let next = Catalog.all.first(where: { !used.contains($0.id) }) {
            config.ringIds.append(next.id)
        }
    }

    private func open(_ app: LauncherApp) {
        if let url = URL(string: app.scheme) {
            UIApplication.shared.open(url)
        }
    }

    /// Legacy relay links (orbitwidget://launch/<id>) from v1.0 widgets.
    private func handleLaunch(_ url: URL) {
        guard url.scheme == "orbitwidget", url.host == "launch" else { return }
        if let app = Catalog.find(url.lastPathComponent) {
            open(app)
        }
    }
}
