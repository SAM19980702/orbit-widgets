import SwiftUI
import UIKit
import WidgetKit

struct ContentView: View {
    @State private var config: RingConfig = ConfigStore.load()
    @State private var spinning = true
    @State private var spinAngle: Double = 0
    @State private var savedTip = false

    private var resolved: (center: LauncherApp, ring: [LauncherApp]) {
        ConfigStore.resolve(config)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    preview
                        .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
                        .listRowBackground(Color.clear)
                }

                Section("中心图标") {
                    Picker("中心 App", selection: $config.centerId) {
                        ForEach(Catalog.all) { app in
                            Text(app.name).tag(app.id)
                        }
                    }
                }

                Section("圆环图标（点右侧按钮换，长按拖动排序）") {
                    ForEach(config.ringIds, id: \.self) { id in
                        HStack(spacing: 12) {
                            if let app = Catalog.find(id) {
                                IconView(app: app, size: 30)
                            }
                            Text(Catalog.find(id)?.name ?? id)
                            Spacer()
                            Menu {
                                ForEach(Catalog.all) { candidate in
                                    Button(candidate.name) { replace(id, with: candidate.id) }
                                }
                            } label: {
                                Image(systemName: "arrow.left.arrow.right.circle")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .onMove { config.ringIds.move(fromOffsets: $0, toOffset: $1) }
                    .onDelete { config.ringIds.remove(atOffsets: $0) }

                    if config.ringIds.count < 14 {
                        Button("添加一个图标") { addNext() }
                    }
                }

                Section("外观") {
                    Toggle("深色背景", isOn: $config.darkBackground)
                    Toggle("预览旋转动画（仅 App 内）", isOn: $spinning)
                }

                Section {
                    Button {
                        ConfigStore.save(config)
                        WidgetCenter.shared.reloadAllTimelines()
                        savedTip = true
                    } label: {
                        Text("保存并刷新小组件")
                            .frame(maxWidth: .infinity)
                    }
                } footer: {
                    Text("保存后，回桌面长按空白处 → 点左上角 + → 搜索 Orbit Widgets → 选大号添加。免费签名可能拦住 App 与小组件之间的数据同步，拦住时小组件会先用默认布局（就是图片那套）。")
                }
            }
            .navigationTitle("Orbit Widgets")
            .toolbar { EditButton() }
            .alert("已保存", isPresented: $savedTip) {
                Button("好", role: .cancel) {}
            }
            .onOpenURL(perform: handleLaunch)
        }
    }

    private var preview: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(config.darkBackground
                    ? LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")], startPoint: .top, endPoint: .bottom)
                    : LinearGradient(colors: [Color.white, Color(hex: "#E9E9EF")], startPoint: .top, endPoint: .bottom))
            RingCanvas(center: resolved.center, ring: resolved.ring, spin: spinning ? spinAngle : 0) { app, size in
                Button { open(app) } label: { IconView(app: app, size: size) }
                    .buttonStyle(.plain)
            }
            .padding(10)
        }
        .aspectRatio(1, contentMode: .fit)
        .onAppear {
            withAnimation(.linear(duration: 30).repeatForever(autoreverses: false)) {
                spinAngle = 360
            }
        }
    }

    // MARK: - Actions

    private func replace(_ oldId: String, with newId: String) {
        guard let idx = config.ringIds.firstIndex(of: oldId) else { return }
        if newId == config.centerId { return }
        if let existing = config.ringIds.firstIndex(of: newId) {
            config.ringIds.swapAt(idx, existing)   // swap instead of duplicating
        } else {
            config.ringIds[idx] = newId
        }
    }

    private func addNext() {
        let used = Set(config.ringIds + [config.centerId])
        if let next = Catalog.all.first(where: { !used.contains($0.id) }) {
            config.ringIds.append(next.id)
        }
    }

    private func open(_ app: LauncherApp) {
        if let url = URL(string: app.scheme) {
            UIApplication.shared.open(url)
        }
    }

    /// Widget icons deep-link here (orbitwidget://launch/<id>); forward to the real app.
    private func handleLaunch(_ url: URL) {
        guard url.scheme == "orbitwidget", url.host == "launch" else { return }
        if let app = Catalog.find(url.lastPathComponent) {
            open(app)
        }
    }
}
