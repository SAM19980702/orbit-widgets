import SwiftUI

/// One launchable app shown as an icon in the ring.
struct LauncherApp: Identifiable, Codable, Equatable {
    var id: String
    var name: String
    var scheme: String       // URL opened when the icon is tapped
    var symbol: String?      // SF Symbol glyph
    var letter: String?      // single character used instead of a glyph
    var colors: [String]     // gradient hex colors, top-leading -> bottom-trailing

    var gradient: LinearGradient {
        let cs = colors.map { Color(hex: $0) }
        return LinearGradient(colors: cs.isEmpty ? [.gray, .black] : cs,
                              startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

extension Color {
    init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.hasPrefix("#") { s.removeFirst() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        let r = Double((v >> 16) & 0xFF) / 255.0
        let g = Double((v >> 8) & 0xFF) / 255.0
        let b = Double(v & 0xFF) / 255.0
        self.init(red: r, green: g, blue: b)
    }
}

/// Built-in catalog of apps the ring can launch (URL-scheme based).
enum Catalog {
    static let all: [LauncherApp] = [
        LauncherApp(id: "wechat",    name: "微信",      scheme: "weixin://",          symbol: "message.fill",                        letter: nil, colors: ["#3BD671", "#05A84E"]),
        LauncherApp(id: "qq",        name: "QQ",        scheme: "mqq://",             symbol: "bubble.left.and.bubble.right.fill",   letter: nil, colors: ["#4FC3F7", "#1E6FD9"]),
        LauncherApp(id: "douyin",    name: "抖音",      scheme: "snssdk1128://",      symbol: "music.note",                          letter: nil, colors: ["#1A1A22", "#000000"]),
        LauncherApp(id: "weibo",     name: "微博",      scheme: "sinaweibo://",       symbol: "eye.fill",                            letter: nil, colors: ["#FF7043", "#E64A19"]),
        LauncherApp(id: "xiaohongshu", name: "小红书",  scheme: "xhsdiscover://",     symbol: nil,                                   letter: "红", colors: ["#FF2442", "#D90429"]),
        LauncherApp(id: "alipay",    name: "支付宝",    scheme: "alipay://",          symbol: nil,                                   letter: "支", colors: ["#42A5F5", "#1565C0"]),
        LauncherApp(id: "taobao",    name: "淘宝",      scheme: "taobao://",          symbol: nil,                                   letter: "淘", colors: ["#FF7043", "#FF5000"]),
        LauncherApp(id: "instagram", name: "Instagram", scheme: "instagram://",       symbol: "camera.fill",                         letter: nil, colors: ["#833AB4", "#FD1D1D", "#FCB045"]),
        LauncherApp(id: "x",         name: "X",         scheme: "twitter://",         symbol: nil,                                   letter: "X", colors: ["#3A3A3C", "#000000"]),
        LauncherApp(id: "youtube",   name: "YouTube",   scheme: "youtube://",         symbol: "play.rectangle.fill",                 letter: nil, colors: ["#FF5252", "#C62828"]),
        LauncherApp(id: "tiktok",    name: "TikTok",    scheme: "tiktok://",          symbol: "music.note",                          letter: nil, colors: ["#FE2C55", "#25F4EE"]),
        LauncherApp(id: "spotify",   name: "Spotify",   scheme: "spotify://",         symbol: "play.circle.fill",                    letter: nil, colors: ["#4ADE80", "#16A34A"]),
        LauncherApp(id: "telegram",  name: "Telegram",  scheme: "tg://",              symbol: "paperplane.fill",                     letter: nil, colors: ["#4FC3F7", "#039BE5"]),
        LauncherApp(id: "whatsapp",  name: "WhatsApp",  scheme: "whatsapp://",        symbol: "message.fill",                        letter: nil, colors: ["#25D366", "#128C7E"]),
        LauncherApp(id: "phone",     name: "电话",      scheme: "tel:",               symbol: "phone.fill",                          letter: nil, colors: ["#4ADE80", "#22C55E"]),
        LauncherApp(id: "sms",       name: "短信",      scheme: "sms:",               symbol: "text.bubble.fill",                    letter: nil, colors: ["#66BB6A", "#43A047"]),
        LauncherApp(id: "maps",      name: "地图",      scheme: "maps://",            symbol: "map.fill",                            letter: nil, colors: ["#81C784", "#388E3C"]),
        LauncherApp(id: "photos",    name: "相册",      scheme: "photos-redirect://", symbol: "photo.fill",                          letter: nil, colors: ["#F06292", "#8E24AA"]),
    ]

    static func find(_ id: String) -> LauncherApp? {
        all.first { $0.id == id }
    }
}
