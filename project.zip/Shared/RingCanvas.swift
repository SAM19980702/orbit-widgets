import SwiftUI

/// A single rounded-square app icon: brand-color gradient + glyph or letter.
struct IconView: View {
    let app: LauncherApp
    let size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(app.gradient)
            if let letter = app.letter {
                Text(letter)
                    .font(.system(size: size * 0.5, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            } else if let symbol = app.symbol {
                Image(systemName: symbol)
                    .font(.system(size: size * 0.48, weight: .semibold))
                    .foregroundStyle(.white)
            }
        }
        .frame(width: size, height: size)
        .shadow(color: .black.opacity(0.35), radius: size * 0.08, x: 0, y: size * 0.04)
    }
}

enum RingPositions {
    static func offset(index: Int, count: Int, radius: CGFloat) -> CGSize {
        let n = max(count, 1)
        let angle = (Double(index) / Double(n)) * 2.0 * Double.pi - Double.pi / 2.0
        return CGSize(width: CGFloat(cos(angle)) * radius,
                      height: CGFloat(sin(angle)) * radius)
    }
}

/// The circular layout shared by the widget and the in-app preview.
/// `icon` wraps an IconView in whatever interaction the host needs
/// (a Link in the widget, a Button in the app).
struct RingCanvas<Icon: View>: View {
    let center: LauncherApp
    let ring: [LauncherApp]
    var spin: Double = 0
    let icon: (LauncherApp, CGFloat) -> Icon

    var body: some View {
        GeometryReader { geo in
            let side = min(geo.size.width, geo.size.height)
            let ringIcon = side * 0.135
            let centerIcon = side * 0.205
            let radius = side * 0.355
            ZStack {
                ZStack {
                    ForEach(Array(ring.enumerated()), id: \.element.id) { idx, app in
                        icon(app, ringIcon)
                            .rotationEffect(.degrees(-spin))
                            .offset(RingPositions.offset(index: idx, count: ring.count, radius: radius))
                    }
                }
                .frame(width: side, height: side)
                .rotationEffect(.degrees(spin))

                icon(center, centerIcon)
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }
}
