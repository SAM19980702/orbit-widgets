import Foundation

/// User's ring layout, shared between the app and the widget through an
/// App Group. When the group is unavailable (e.g. free re-signing stripped
/// the entitlement) both sides fall back to `defaultConfig`, so the widget
/// still shows the picture-style default ring.
struct RingConfig: Codable, Equatable {
    var centerId: String
    var ringIds: [String]
    var darkBackground: Bool = true
}

enum ConfigStore {
    static let suiteName = "group.com.sam.orbitwidget"
    private static let key = "ringConfig.v1"

    static var defaultConfig: RingConfig {
        RingConfig(
            centerId: "instagram",
            ringIds: ["wechat", "x", "youtube", "spotify", "telegram", "tiktok",
                      "alipay", "qq", "weibo", "xiaohongshu", "taobao", "whatsapp"],
            darkBackground: true
        )
    }

    static func load() -> RingConfig {
        guard let defaults = UserDefaults(suiteName: suiteName),
              let data = defaults.data(forKey: key),
              let cfg = try? JSONDecoder().decode(RingConfig.self, from: data)
        else { return defaultConfig }
        return cfg
    }

    static func save(_ cfg: RingConfig) {
        guard let defaults = UserDefaults(suiteName: suiteName),
              let data = try? JSONEncoder().encode(cfg)
        else { return }
        defaults.set(data, forKey: key)
    }

    static func resolve(_ cfg: RingConfig) -> (center: LauncherApp, ring: [LauncherApp]) {
        let center = Catalog.find(cfg.centerId) ?? Catalog.all[0]
        let ring = cfg.ringIds.compactMap { Catalog.find($0) }
        return (center, ring)
    }
}
