import Foundation

/// User's ring layout, shared between the app and the widget through an
/// App Group. When the group is unavailable (e.g. free re-signing stripped
/// the entitlement) both sides fall back to `defaultConfig`, so the widget
/// still shows the picture-style default ring.
struct RingConfig: Codable, Equatable {
    var centerId: String
    var ringIds: [String]
    /// "dark" | "light" | "wallpaper" (wallpaper = cropped screenshot, looks transparent)
    var background: String = "dark"
    /// Where the widget sits on the home screen: "top" | "middle" | "bottom"
    var wallpaperPosition: String = "middle"

    enum CodingKeys: String, CodingKey {
        case centerId, ringIds, background, wallpaperPosition, darkBackground
    }

    init(centerId: String, ringIds: [String],
         background: String = "dark", wallpaperPosition: String = "middle") {
        self.centerId = centerId
        self.ringIds = ringIds
        self.background = background
        self.wallpaperPosition = wallpaperPosition
    }

    /// Tolerant decoding: v1.0 configs stored `darkBackground` instead of `background`.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        centerId = try c.decode(String.self, forKey: .centerId)
        ringIds = try c.decode([String].self, forKey: .ringIds)
        if let bg = try c.decodeIfPresent(String.self, forKey: .background) {
            background = bg
        } else if let dark = try c.decodeIfPresent(Bool.self, forKey: .darkBackground) {
            background = dark ? "dark" : "light"
        } else {
            background = "dark"
        }
        wallpaperPosition = try c.decodeIfPresent(String.self, forKey: .wallpaperPosition) ?? "middle"
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(centerId, forKey: .centerId)
        try c.encode(ringIds, forKey: .ringIds)
        try c.encode(background, forKey: .background)
        try c.encode(wallpaperPosition, forKey: .wallpaperPosition)
    }
}

enum ConfigStore {
    static let suiteName = "group.com.sam.orbitwidget"
    private static let key = "ringConfig.v1"

    static var defaultConfig: RingConfig {
        RingConfig(
            centerId: "instagram",
            ringIds: ["wechat", "x", "youtube", "spotify", "telegram", "tiktok",
                      "alipay", "qq", "weibo", "xiaohongshu", "taobao", "whatsapp"],
            background: "dark"
        )
    }

    static func load() -> RingConfig {
        guard let defaults = UserDefaults(suiteName: suiteName),
              let data = defaults.data(forKey: key),
              let cfg = try? JSONDecoder().decode(RingConfig.self, from: data)
        else { return defaultConfig }
        return cfg
    }

    static func save(_ cfg: RingConfig) {
        guard let defaults = UserDefaults(suiteName: suiteName),
              let data = try? JSONEncoder().encode(cfg)
        else { return }
        defaults.set(data, forKey: key)
    }

    static func resolve(_ cfg: RingConfig) -> (center: LauncherApp, ring: [LauncherApp]) {
        let center = Catalog.find(cfg.centerId) ?? Catalog.all[0]
        let ring = cfg.ringIds.compactMap { Catalog.find($0) }
        return (center, ring)
    }

    // MARK: - Wallpaper (cropped home-screen screenshot used as widget background)

    private static var wallpaperURL: URL? {
        FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: suiteName)?
            .appendingPathComponent("wallpaper.jpg")
    }

    static func saveWallpaper(_ data: Data) {
        guard let url = wallpaperURL else { return }
        try? data.write(to: url, options: .atomic)
    }

    static func loadWallpaperData() -> Data? {
        guard let url = wallpaperURL else { return nil }
        return try? Data(contentsOf: url)
    }
}
