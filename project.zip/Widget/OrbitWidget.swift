import WidgetKit
import SwiftUI

struct OrbitEntry: TimelineEntry {
    let date: Date
    let center: LauncherApp
    let ring: [LauncherApp]
    let dark: Bool
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> OrbitEntry { makeEntry() }

    func getSnapshot(in context: Context, completion: @escaping (OrbitEntry) -> Void) {
        completion(makeEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<OrbitEntry>) -> Void) {
        completion(Timeline(entries: [makeEntry()], policy: .never))
    }

    private func makeEntry() -> OrbitEntry {
        let cfg = ConfigStore.load()
        let (center, ring) = ConfigStore.resolve(cfg)
        return OrbitEntry(date: Date(), center: center, ring: ring, dark: cfg.darkBackground)
    }
}

struct RingWidgetView: View {
    let entry: OrbitEntry

    var body: some View {
        RingCanvas(center: entry.center, ring: entry.ring) { app, size in
            Link(destination: URL(string: "orbitwidget://launch/\(app.id)")!) {
                IconView(app: app, size: size)
            }
        }
        .padding(6)
    }
}

struct OrbitWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "OrbitWidget", provider: Provider()) { entry in
            RingWidgetView(entry: entry)
                .containerBackground(for: .widget) {
                    if entry.dark {
                        LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")],
                                       startPoint: .top, endPoint: .bottom)
                    } else {
                        LinearGradient(colors: [Color.white, Color(hex: "#E9E9EF")],
                                       startPoint: .top, endPoint: .bottom)
                    }
                }
        }
        .configurationDisplayName("环形启动器")
        .description("常用 App 围成一圈，点图标直达。")
        .supportedFamilies([.systemLarge])
    }
}

@main
struct OrbitWidgetBundle: WidgetBundle {
    var body: some Widget {
        OrbitWidget()
    }
}
