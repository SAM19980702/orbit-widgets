import WidgetKit
import SwiftUI
import UIKit

struct OrbitEntry: TimelineEntry {
    let date: Date
    let center: LauncherApp
    let ring: [LauncherApp]
    let background: String
    let wallpaper: UIImage?
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> OrbitEntry { makeEntry() }

    func getSnapshot(in context: Context, completion: @escaping (OrbitEntry) -> Void) {
        completion(makeEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<OrbitEntry>) -> Void) {
        completion(Timeline(entries: [makeEntry()], policy: .never))
    }

    private func makeEntry() -> OrbitEntry {
        let cfg = ConfigStore.load()
        let (center, ring) = ConfigStore.resolve(cfg)
        var wallpaper: UIImage? = nil
        if cfg.background == "wallpaper",
           let data = ConfigStore.loadWallpaperData() {
            wallpaper = UIImage(data: data)
        }
        return OrbitEntry(date: Date(), center: center, ring: ring,
                          background: cfg.background, wallpaper: wallpaper)
    }
}

struct RingWidgetView: View {
    let entry: OrbitEntry

    var body: some View {
        RingCanvas(center: entry.center, ring: entry.ring) { app, size in
            // Direct link to the target app's own URL scheme — no relay
            // through the Orbit app.
            Link(destination: URL(string: app.scheme)!) {
                IconView(app: app, size: size)
            }
        }
        .padding(6)
    }
}

struct WidgetBackground: View {
    let entry: OrbitEntry

    var body: some View {
        switch entry.background {
        case "light":
            LinearGradient(colors: [Color.white, Color(hex: "#E9E9EF")],
                           startPoint: .top, endPoint: .bottom)
        case "wallpaper":
            if let wallpaper = entry.wallpaper {
                Image(uiImage: wallpaper)
                    .resizable()
                    .scaledToFill()
            } else {
                LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")],
                               startPoint: .top, endPoint: .bottom)
            }
        default:
            LinearGradient(colors: [Color(hex: "#232329"), Color(hex: "#050506")],
                           startPoint: .top, endPoint: .bottom)
        }
    }
}

struct OrbitWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "OrbitWidget", provider: Provider()) { entry in
            RingWidgetView(entry: entry)
                .containerBackground(for: .widget) {
                    WidgetBackground(entry: entry)
                }
        }
        .configurationDisplayName("环形启动器")
        .description("常用 App 围成一圈，点图标直达。")
        .supportedFamilies([.systemLarge])
    }
}

@main
struct OrbitWidgetBundle: WidgetBundle {
    var body: some Widget {
        OrbitWidget()
    }
}
